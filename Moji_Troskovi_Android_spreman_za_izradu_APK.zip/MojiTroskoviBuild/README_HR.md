# Moji troškovi – priprema APK-a bez pisanja koda

Projekt sadrži Android aplikaciju na hrvatskom jeziku. Unosi se datum, vrsta troška, iznos i napomena. Podaci se spremaju lokalno na uređaj, a aplikacija prikazuje mjesečni zbroj i popis troškova.

## Kako dobiti APK bez programiranja (putem GitHub Actions)

Za ovaj postupak treba GitHub račun i internetski preglednik. Ne treba pisati niti mijenjati programski kod.

1. Na GitHubu izradite novi, prazni repozitorij (npr. `moji-troskovi`).
2. Raspakirajte ovaj ZIP na računalu.
3. U repozitorij prenesite sve datoteke i mape iz raspakirane mape, uključujući skrivenu mapu `.github`.
4. Na GitHub stranici projekta otvorite karticu **Actions**.
5. Odaberite tijek rada **Izrada APK-a** i pritisnite **Run workflow**.
6. Kad postupak završi zelenom kvačicom, otvorite izvršeni postupak i pri dnu odjeljak **Artifacts**.
7. Preuzmite `MojiTroskovi-APK.zip` i raspakirajte ga. Unutra je `app-debug.apk`.
8. Prenesite APK na Android mobitel i otvorite ga. Ako Android zatraži dopuštenje, odobrite instalaciju iz tog izvora.

## Važno
- APK koji se izrađuje ovim postupkom je debug APK, prikladan za osobnu instalaciju i testiranje.
- Aplikacija nema korisnički račun ni sinkronizaciju u oblaku. Podaci ostaju u lokalnoj bazi na telefonu; deinstalacijom aplikacije mogu se izbrisati.
- Datum se u ovoj prvoj verziji upisuje u obliku `GGGG-MM-DD`, primjerice `2026-11-07`.
- Ovaj ZIP sadrži projekt i automatizirani postupak izrade; APK nije unaprijed kompajliran u ovom okruženju.
