package hr.mojitroskovi

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.room.*
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale

@Entity(tableName = "troskovi")
data class Trosak(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val datum: String,
    val vrsta: String,
    val iznos: Double,
    val napomena: String
)

@Dao
interface TrosakDao {
    @Query("SELECT * FROM troskovi ORDER BY datum DESC, id DESC")
    fun svi(): kotlinx.coroutines.flow.Flow<List<Trosak>>
    @Insert suspend fun dodaj(t: Trosak)
    @Delete suspend fun obrisi(t: Trosak)
}

@Database(entities = [Trosak::class], version = 1, exportSchema = false)
abstract class TrosakBaza : RoomDatabase() {
    abstract fun dao(): TrosakDao
    companion object {
        @Volatile private var INSTANCE: TrosakBaza? = null
        fun get(ctx: android.content.Context) = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(ctx.applicationContext, TrosakBaza::class.java, "moji_troskovi.db").build().also { INSTANCE = it }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dao = TrosakBaza.get(this).dao()
        setContent { MaterialTheme { Ekran(dao) } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Ekran(dao: TrosakDao) {
    val scope = rememberCoroutineScope()
    val troskovi by dao.svi().collectAsState(initial = emptyList())
    var datum by remember { mutableStateOf(LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE)) }
    var vrsta by remember { mutableStateOf("Struja") }
    var iznos by remember { mutableStateOf("") }
    var napomena by remember { mutableStateOf("") }
    var mjesec by remember { mutableStateOf(YearMonth.now()) }
    var prikaziFormu by remember { mutableStateOf(true) }
    val kategorije = listOf("Struja", "Voda", "Plin", "Internet", "Pričuva", "Smeće", "Hrana", "Gorivo", "Stanovanje", "Zdravlje", "Odjeća", "Popravci", "Ostalo")
    val mjesecni = troskovi.filter { runCatching { YearMonth.from(LocalDate.parse(it.datum)) == mjesec }.getOrDefault(false) }
    val ukupno = mjesecni.sumOf { it.iznos }
    val valuta = remember { NumberFormat.getCurrencyInstance(Locale("hr", "HR")) }
    val fmt = DateTimeFormatter.ofPattern("dd.MM.yyyy.")

    Scaffold(topBar = { TopAppBar(title = { Text("Moji troškovi") }) }) { padding ->
        Column(Modifier.padding(padding).padding(16.dp).fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Mjesečni pregled", style = MaterialTheme.typography.titleMedium)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        TextButton(onClick = { mjesec = mjesec.minusMonths(1) }) { Text("‹ Prethodni") }
                        Text(mjesec.format(DateTimeFormatter.ofPattern("MMMM yyyy", Locale("hr", "HR"))).replaceFirstChar { it.uppercase() })
                        TextButton(onClick = { mjesec = mjesec.plusMonths(1) }) { Text("Sljedeći ›") }
                    }
                    Text("Ukupno: ${valuta.format(ukupno)}", style = MaterialTheme.typography.headlineSmall)
                    Text("Broj stavki: ${mjesecni.size}")
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Unos troška", style = MaterialTheme.typography.titleLarge)
                TextButton(onClick = { prikaziFormu = !prikaziFormu }) { Text(if (prikaziFormu) "Sakrij" else "Prikaži") }
            }
            if (prikaziFormu) {
                OutlinedTextField(value = datum, onValueChange = { datum = it }, label = { Text("Datum (GGGG-MM-DD)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                var prosiri by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(expanded = prosiri, onExpandedChange = { prosiri = !prosiri }) {
                    OutlinedTextField(value = vrsta, onValueChange = {}, readOnly = true, label = { Text("Vrsta troška") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = prosiri) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                    ExposedDropdownMenu(expanded = prosiri, onDismissRequest = { prosiri = false }) {
                        kategorije.forEach { k -> DropdownMenuItem(text = { Text(k) }, onClick = { vrsta = k; prosiri = false }) }
                    }
                }
                OutlinedTextField(value = iznos, onValueChange = { iznos = it.replace(',', '.').filter { c -> c.isDigit() || c == '.' } }, label = { Text("Iznos (€)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(value = napomena, onValueChange = { napomena = it }, label = { Text("Napomena (nije obavezna)") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                Button(onClick = {
                    val d = runCatching { LocalDate.parse(datum) }.getOrNull()
                    val a = iznos.toDoubleOrNull()
                    if (d != null && a != null && a > 0) {
                        scope.launch { dao.dodaj(Trosak(datum, vrsta, a, napomena.trim())) }
                        mjesec = YearMonth.from(d)
                        iznos = ""; napomena = ""
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text("Spremi trošak") }
                Text("Datum upiši u obliku GGGG-MM-DD, npr. 2026-11-05.", style = MaterialTheme.typography.bodySmall)
            }
            Text("Troškovi za odabrani mjesec", style = MaterialTheme.typography.titleLarge)
            if (mjesecni.isEmpty()) Text("Nema unesenih troškova za ovaj mjesec.")
            mjesecni.forEach { t ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text(t.vrsta, style = MaterialTheme.typography.titleMedium)
                            Text(runCatching { LocalDate.parse(t.datum).format(fmt) }.getOrDefault(t.datum))
                            if (t.napomena.isNotBlank()) Text("Napomena: ${t.napomena}", style = MaterialTheme.typography.bodySmall)
                        }
                        Column(horizontalAlignment = androidx.compose.ui.Alignment.End) {
                            Text(valuta.format(t.iznos), style = MaterialTheme.typography.titleMedium)
                            TextButton(onClick = { scope.launch { dao.obrisi(t) } }) { Text("Obriši") }
                        }
                    }
                }
            }
        }
    }
}
